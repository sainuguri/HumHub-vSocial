<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} heeft een nieuwe stembus aangemaakt en jou aangewezen.',
);
