<?php
return array (
  'Ask' => 'Paklausti',
);
