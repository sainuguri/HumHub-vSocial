<?php
return array (
  'Answers' => 'Respuestas',
  'Multiple answers per user' => 'Multiples respuestas por usuario',
  'Please specify at least {min} answers!' => '¡Por favor, especifica al menos {min} respuestas!',
  'Question' => 'Pregunta',
);
