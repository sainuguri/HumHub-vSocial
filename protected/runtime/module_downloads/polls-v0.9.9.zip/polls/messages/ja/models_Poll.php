<?php
return array (
  'Answers' => '回答',
  'Multiple answers per user' => 'ユーザーごとの複数回答',
  'Please specify at least {min} answers!' => '最低{min}門は回答してください！',
  'Question' => '質問',
);
