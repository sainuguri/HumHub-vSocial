<?php
return array (
  'Access denied!' => 'アクセスが拒否されました！',
  'Anonymous poll!' => '',
  'Could not load poll!' => 'アンケートを読み込めませんでした！',
  'Invalid answer!' => '無効な回答！',
  'Users voted for: <strong>{answer}</strong>' => 'ユーザーが投票した：<strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => '複数回答のために投票が無効になっています！',
  'You have insufficient permissions to perform that operation!' => 'あなたはその操作を実行するための十分な権限を持っている！',
);
