<?php
return array (
  'Recipient' => 'Destinatario',
  'You cannot send a email to yourself!' => 'Non puoi inviare un\'email a te stesso!',
);
