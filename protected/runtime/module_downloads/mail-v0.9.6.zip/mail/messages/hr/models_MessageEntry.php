<?php
return array (
  'New message in discussion from %displayName%' => '',
);
