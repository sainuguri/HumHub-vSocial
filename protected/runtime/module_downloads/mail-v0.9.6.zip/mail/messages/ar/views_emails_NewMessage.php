<?php
return array (
  '<strong>New</strong> message' => 'رسالة <strong>جديدة</strong>',
  'Reply now' => 'اضف رد',
  'sent you a new message:' => 'ارسل لك رسالة جديدة:',
);
