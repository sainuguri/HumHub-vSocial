<?php
return array (
  'Messages' => 'Berichten',
  'New message' => 'Nieuw bericht',
  'Show all messages' => 'Toon alle berichten',
);
