<?php
return array (
  'Allow others to send you private messages' => 'Sta anderen toe om u privéberichten te sturen',
  'Created At' => 'Gemaakt op',
  'Created By' => 'Gemaakt door',
  'Is Originator' => 'Is beginner',
  'Last Viewed' => 'Laatst weergegeven',
  'Message' => 'Bericht',
  'Messages' => 'Berichten',
  'Receive private messages' => 'Ontvang privéberichten',
  'Title' => 'Titel',
  'Updated At' => 'Geüpdate op',
  'Updated By' => 'Geüpdate door',
  'User' => 'Gebruiker',
);
