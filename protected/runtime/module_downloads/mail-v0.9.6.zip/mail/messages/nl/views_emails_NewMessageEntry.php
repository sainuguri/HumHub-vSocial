<?php
return array (
  'sent you a new message in' => 'stuurde je een nieuw bericht in',
);
