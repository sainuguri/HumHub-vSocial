<?php
return array (
  'Add recipients' => '',
  'Close' => 'Zatvori',
  'New message' => 'Új üzenet',
  'Send' => 'Beküldés',
);
