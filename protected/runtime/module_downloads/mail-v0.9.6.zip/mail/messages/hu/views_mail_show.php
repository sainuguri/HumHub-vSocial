<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '',
  '<strong>Confirm</strong> leaving conversation' => '',
  '<strong>Confirm</strong> message deletion' => '',
  'Add user' => 'További címzettek',
  'Cancel' => 'Mégsem',
  'Delete' => 'Törlés',
  'Delete conversation' => 'Beszélgetés törlése',
  'Do you really want to delete this conversation?' => '',
  'Do you really want to delete this message?' => '',
  'Do you really want to leave this conversation?' => '',
  'Leave' => '',
  'Leave conversation' => 'Kilépés a beszélgetésből',
  'Leave discussion' => '',
  'Send' => 'Küldés',
  'There are no messages yet.' => 'Még nincs üzenet.',
  'Write an answer...' => 'Ide írhatod az üzenetet...',
);
