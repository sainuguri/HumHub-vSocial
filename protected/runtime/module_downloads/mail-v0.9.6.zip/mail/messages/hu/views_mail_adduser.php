<?php
return array (
  'Add more participants to your conversation...' => '',
  'Close' => 'Zatvori',
  'Send' => 'Beküldés',
);
