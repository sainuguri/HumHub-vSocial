<?php
return array (
  'There are no messages yet.' => 'Még nincs üzenet.',
);
