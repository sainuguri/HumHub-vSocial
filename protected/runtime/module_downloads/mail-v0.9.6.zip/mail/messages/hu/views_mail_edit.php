<?php
return array (
  'Edit message entry' => '',
  'Save' => 'Mentés',
);
