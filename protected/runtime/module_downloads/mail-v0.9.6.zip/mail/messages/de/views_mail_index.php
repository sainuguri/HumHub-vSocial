<?php
return array (
  'Conversations' => 'Unterhaltungen',
  'New' => 'Neu',
  'New message' => 'Neue Nachricht',
  'There are no messages yet.' => 'Es sind keine Nachrichten vorhanden.',
);
