<?php
return array (
  'New message' => '新規メッセージ',
  'Send message' => '',
);
