<?php
return array (
  'Message' => 'Ziņa',
);
