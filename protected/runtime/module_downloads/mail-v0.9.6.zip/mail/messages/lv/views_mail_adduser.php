<?php
return array (
  'Add more participants to your conversation...' => 'Pievieno vairāk dalībniekus savai sarunai...',
  'Close' => 'Aizvērt',
  'Send' => 'Sūtīt',
);
