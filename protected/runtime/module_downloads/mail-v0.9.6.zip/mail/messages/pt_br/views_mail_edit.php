<?php
return array (
  'Edit message entry' => 'Editar mensagem',
  'Save' => 'Salvar',
);
