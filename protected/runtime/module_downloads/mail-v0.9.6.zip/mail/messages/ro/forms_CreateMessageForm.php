<?php
return array (
  'Message' => 'Mesaj',
  'Recipient' => '',
  'Subject' => '제목',
  'You cannot send a email to yourself!' => '',
);
