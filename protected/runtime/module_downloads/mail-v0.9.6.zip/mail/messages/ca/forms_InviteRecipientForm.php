<?php
return array (
  'Recipient' => 'Destinatari',
  'You cannot send a email to yourself!' => '',
);
