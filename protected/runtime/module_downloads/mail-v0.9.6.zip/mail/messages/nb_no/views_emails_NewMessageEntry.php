<?php
return array (
  'sent you a new message in' => 'sendte deg en ny melding i',
);
