<?php
return array (
  'Conversations' => 'Samtaler',
  'New' => 'Ny',
  'New message' => 'Ny melding',
  'There are no messages yet.' => 'Det er ingen meldinger her enda.',
);
