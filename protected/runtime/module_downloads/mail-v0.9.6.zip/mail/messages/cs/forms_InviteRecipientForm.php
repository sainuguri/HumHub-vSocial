<?php
return array (
  'Recipient' => 'Příjemce',
  'You cannot send a email to yourself!' => 'Nemůžete poslat zprávu sami sobě.',
);
