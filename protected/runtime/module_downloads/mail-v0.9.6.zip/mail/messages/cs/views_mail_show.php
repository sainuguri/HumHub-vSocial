<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Smazání</strong> konverzace',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Opuštění</strong> konverzace',
  '<strong>Confirm</strong> message deletion' => '<strong>Smazání</strong> zprávy',
  'Add user' => 'Přidat uživatele',
  'Cancel' => 'Zrušit',
  'Delete' => 'Smazat',
  'Delete conversation' => 'Smazat konverzaci',
  'Do you really want to delete this conversation?' => 'Opravdu chcete smazat tuto konverzaci?',
  'Do you really want to delete this message?' => 'Opravdu chcete smazat tuto zprávu?',
  'Do you really want to leave this conversation?' => 'Opravdu chcete opustit tuto konverzaci?',
  'Leave' => 'Opustit',
  'Leave conversation' => 'Opustit konverzaci',
  'Leave discussion' => 'Opustit konverzaci',
  'Send' => 'Poslat',
  'There are no messages yet.' => 'Zatím zde nejsou žádné zprávy.',
  'Write an answer...' => 'Napsat odpověď...',
);
