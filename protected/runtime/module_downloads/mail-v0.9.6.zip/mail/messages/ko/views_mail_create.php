<?php
return array (
  'Add recipients' => '',
  'Close' => '닫기',
  'New message' => '',
  'Send' => '',
);
