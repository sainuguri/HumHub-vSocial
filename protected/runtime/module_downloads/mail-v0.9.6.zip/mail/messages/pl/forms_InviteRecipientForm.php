<?php
return array (
  'Recipient' => 'Odbiorca ',
  'You cannot send a email to yourself!' => 'Nie możesz wysłać wiadomości do samego siebie!',
);
