<?php
return array (
  'Add more participants to your conversation...' => '',
  'Close' => 'Tutup',
  'Send' => 'Kirim',
);
