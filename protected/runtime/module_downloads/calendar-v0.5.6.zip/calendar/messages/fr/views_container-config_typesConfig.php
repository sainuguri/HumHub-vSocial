<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Créer</strong> un nouveau type d\'événement',
  '<strong>Create</strong> new type' => '<strong>Créer</strong> un nouveau type',
  '<strong>Edit</strong> event type' => '<strong>Modifier</strong> un type d\'événement',
);
