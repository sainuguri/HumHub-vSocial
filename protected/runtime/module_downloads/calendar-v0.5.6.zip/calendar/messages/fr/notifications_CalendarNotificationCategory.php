<?php
return array (
  'Calendar' => 'Calendrier',
  'Receive Calendar related Notifications.' => 'Recevoir les notifications liées au calendrier',
);
