<?php
return array (
  'Attend' => 'Participe',
  'Decline' => 'Refuse',
  'Maybe' => 'Peut-être',
  'Participant information:' => 'Informations :',
  'Read full description...' => 'Lire la description complète...',
  'Read full participation info...' => 'Lire les informations complètes...',
);
