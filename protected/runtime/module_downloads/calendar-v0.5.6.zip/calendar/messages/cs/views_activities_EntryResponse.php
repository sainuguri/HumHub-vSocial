<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% se zúčastní události %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% se možná zúčastní události %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% se nezúčastní události %contentTitle%.',
);
