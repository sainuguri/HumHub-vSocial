<?php
return array (
  '<strong>Filter</strong> events' => '<strong>فیلتر کردن</strong> رویدادها',
  '<strong>Select</strong> calendars' => '<strong>انتخاب</strong> تقویم‌ها',
  'Already responded' => 'پاسخ قبلا داده‌شده‌است',
  'Followed spaces' => 'انجمن‌های دنبال‌شده',
  'Followed users' => 'کاربران دنبال‌شده',
  'I´m attending' => 'حضور خواهم‌داشت',
  'My events' => 'رویدادهای من',
  'My profile' => 'پروفایل من',
  'My spaces' => 'انجمن‌های من',
  'Not responded yet' => 'هنوز پاسخ داده‌نشده‌است',
);
