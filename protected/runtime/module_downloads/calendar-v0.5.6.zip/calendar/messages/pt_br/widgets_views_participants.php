<?php
return array (
  ':count attending' => ':count participando',
  ':count declined' => ':count recusado',
  ':count maybe' => ':count talvez',
  'Participants:' => 'Participantes:',
);
