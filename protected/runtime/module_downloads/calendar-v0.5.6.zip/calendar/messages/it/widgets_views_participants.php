<?php
return array (
  ':count attending' => ':numero partecipanti',
  ':count declined' => ':numero rifiuti',
  ':count maybe' => ':numero in forse',
  'Participants:' => 'Partecipanti:',
);
