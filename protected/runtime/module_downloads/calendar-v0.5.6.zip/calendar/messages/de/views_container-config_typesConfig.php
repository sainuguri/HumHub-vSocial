<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Erstelle</strong> eine neue Kategorie',
  '<strong>Create</strong> new type' => '<strong>Erstelle</strong> eine neue Kategorie',
  '<strong>Edit</strong> event type' => '<strong>Bearbeite</strong> eine Kategorie',
);
