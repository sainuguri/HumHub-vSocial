<?php
return array (
  ':count attending' => '：参加者数',
  ':count declined' => '：参加辞退者数',
  ':count maybe' => '：参加未定者数',
  'Participants:' => '参加者：',
);
