<?php
return array (
  'Defaults' => 'Standaard instellingen',
  'Event Types' => 'Gebeurtenis-types',
  'Snippet' => 'Codefragment',
);
