<?php
return array (
  'Calendar' => 'Agenda',
  'Receive Calendar related Notifications.' => 'Ontvang agenda gerelateerde meldingen.',
);
