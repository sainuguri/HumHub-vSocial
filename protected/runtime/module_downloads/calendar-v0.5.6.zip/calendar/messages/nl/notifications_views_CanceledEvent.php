<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} annuleerde gebeurtenis \'{contentTitle}\' in ruimte {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} annuleerde gebeurtenis \'{contentTitle}\'.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} werkte zojuist gebeurtenis {contentTitle} in ruimte {spaceName} bij.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} werkte zojuist gebeurtenis {contentTitle} bij.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} heropende gebeurtenis {contentTitle} in ruimte {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} heropende gebeurtenis {contentTitle}.',
);
