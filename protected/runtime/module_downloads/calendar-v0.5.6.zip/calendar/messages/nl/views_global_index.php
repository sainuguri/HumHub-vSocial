<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> evenementen',
  '<strong>Select</strong> calendars' => '<strong>Selecteer</strong> agendas',
  'Already responded' => 'Reeds gereageerd',
  'Followed spaces' => 'Gevolgde ruimtes',
  'Followed users' => 'Gevolgde gebruikers',
  'I´m attending' => 'Waar ik aan deelneem',
  'My events' => 'Mijn evenementen',
  'My profile' => 'Mijn profiel',
  'My spaces' => 'Mijn ruimtes',
  'Not responded yet' => 'Nog niet gereageerd',
);
