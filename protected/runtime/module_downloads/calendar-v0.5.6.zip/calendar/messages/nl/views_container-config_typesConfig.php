<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Maak</strong> nieuw gebeurtenistype',
  '<strong>Create</strong> new type' => '<strong>Maak</strong> nieuw type',
  '<strong>Edit</strong> event type' => '<strong>Bewerk</strong> gebeurtenistype',
);
