<?php
return array (
  'Allows the user to create new calendar entries' => 'Cho phép người dùng tạo mục lịch biểu mới',
  'Allows the user to edit/delete existing calendar entries' => 'Cho phép người dùng chỉnh sửa/xóa mục lịch biểu hiện có',
  'Create entry' => 'Tạo mục mới',
  'Manage entries' => 'Quản lý mục',
);
