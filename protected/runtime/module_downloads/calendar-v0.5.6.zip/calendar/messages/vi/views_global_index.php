<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Lọc</strong> sự kiện',
  '<strong>Select</strong> calendars' => '<strong>Chọn</strong> lịch',
  'Already responded' => 'Đã phản hồi',
  'Followed spaces' => 'Các phòng được theo dõi',
  'Followed users' => 'Các user được theo dõi',
  'I´m attending' => 'Tôi đang tham gia',
  'My events' => 'Sự kiện của tôi',
  'My profile' => 'Hồ sơ của tôi',
  'My spaces' => 'Phòng làm việc của tôi',
  'Not responded yet' => 'Chưa trả lời',
);
