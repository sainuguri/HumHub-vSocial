<?php
return array (
  'Calendar' => 'Lịch',
  'Receive Calendar related Notifications.' => 'Nhận các thông báo liên quan tới Lịch.',
);
