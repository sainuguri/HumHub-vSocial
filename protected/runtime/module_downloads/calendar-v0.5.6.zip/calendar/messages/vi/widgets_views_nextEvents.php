<?php
return array (
  '<strong>Upcoming</strong> events ' => 'Các sự kiện <strong>sắp diễn ra</strong>',
  'Open Calendar' => 'Mở lịch',
);
