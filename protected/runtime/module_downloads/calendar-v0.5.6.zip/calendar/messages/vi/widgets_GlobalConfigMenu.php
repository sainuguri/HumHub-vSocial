<?php
return array (
  'Defaults' => 'Mặc định',
  'Event Types' => 'Loại sự kiện',
  'Snippet' => 'Snippet',
);
