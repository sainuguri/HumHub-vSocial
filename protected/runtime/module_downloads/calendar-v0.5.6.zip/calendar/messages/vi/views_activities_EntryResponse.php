<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% tham gia %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% có thể sẽ tham gia %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% không tham gia %contentTitle%.',
);
