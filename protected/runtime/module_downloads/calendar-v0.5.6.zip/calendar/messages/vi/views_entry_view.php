<?php
return array (
  'Attend' => 'Tham dự',
  'Decline' => 'Từ chối',
  'Maybe' => 'Có thể',
  'Participant information:' => 'Thông tin người tham dự:',
  'Read full description...' => 'Đọc toàn bộ mô tả...',
  'Read full participation info...' => 'Đọc toàn bộ thông tin tham dự...',
);
