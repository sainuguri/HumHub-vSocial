<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Tạo</strong> loại sự kiện mới',
  '<strong>Create</strong> new type' => '<strong>Tạo</strong> loại mới',
  '<strong>Edit</strong> event type' => '<strong>Chỉnh sửa</strong> loại sự kiện',
);
