<?php
return array (
  '<strong>Create</strong> event' => '<strong>Tạo</strong> sự kiện',
  '<strong>Edit</strong> event' => '<strong>Chỉnh sửa</strong> sự kiện',
  'Basic' => 'Cơ bản',
  'Everybody can participate' => 'Ai cũng có thể tham gia',
  'Files' => 'Files',
  'No participants' => 'Không có người tham gia',
  'Participation' => 'Tham gia',
  'Select event type...' => 'Chọn loại sự kiện...',
  'Title' => 'Tiêu đề',
);
