<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} đã hủy sự kiện \'{contentTitle}\' trong phòng {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} đã hủy sự kiện \'{contentTitle}\'.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} vừa mới cập nhật {contentTitle} trong phòng {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} vừa mới cập nhật sự kiện {contentTitle}.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} đã mở lại sự kiện {contentTitle} trong phòng {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} đã mở lại sự kiện {contentTitle}.',
);
