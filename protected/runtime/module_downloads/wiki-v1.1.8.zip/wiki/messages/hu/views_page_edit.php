<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Új oldal</strong> létrehozása',
  '<strong>Edit</strong> page' => 'Oldal <strong>szerkesztése</strong>',
  'Enter a wiki page name or url (e.g. http://example.com)' => '',
  'New page title' => 'Oldal címe',
  'Page content' => 'Oldal tartalma',
  'Save' => 'Mentés',
);
