<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Opret</strong> ny side',
  '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Indtast en wiki side navn eller url (e.g. http://example.com)',
  'New page title' => 'Ny side titel',
  'Page content' => 'Side indhold',
  'Save' => 'Gem',
);
