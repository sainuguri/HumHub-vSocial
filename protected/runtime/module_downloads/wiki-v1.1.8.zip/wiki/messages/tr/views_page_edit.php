<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Yeni</strong> sayfa oluştur',
  '<strong>Edit</strong> page' => '<strong>Sayfayı</strong> Düzenle',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Wiki sayfası adı veya url girin (örnek: http://example.com)',
  'New page title' => 'Yeni Sayfa Başlığı',
  'Page content' => 'Sayfa içeriği',
  'Save' => 'Kaydet',
);
