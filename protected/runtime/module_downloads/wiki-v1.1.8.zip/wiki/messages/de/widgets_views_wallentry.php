<?php
return array (
  'Open wiki page...' => 'Ganze Wiki-Seite lesen ...',
);
