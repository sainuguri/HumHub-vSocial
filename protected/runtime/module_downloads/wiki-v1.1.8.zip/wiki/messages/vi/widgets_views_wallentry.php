<?php
return array (
  'Open wiki page...' => 'Mở trang Wiki...',
);
