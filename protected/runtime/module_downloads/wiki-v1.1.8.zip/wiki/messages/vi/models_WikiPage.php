<?php
return array (
  'Wiki page' => 'Trang Wiki',
);
