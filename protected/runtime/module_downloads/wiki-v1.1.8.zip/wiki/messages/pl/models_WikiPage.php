<?php
return array (
  'Wiki page' => 'Strona Wiki',
);
