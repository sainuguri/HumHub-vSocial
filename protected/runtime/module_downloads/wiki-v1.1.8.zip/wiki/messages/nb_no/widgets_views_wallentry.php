<?php
return array (
  'Open wiki page...' => 'Åpne wikiside...',
);
