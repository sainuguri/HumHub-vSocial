<?php
return array (
  'Wiki page' => 'Wikiside',
);
