## Description

This widget showing upcoming birthdays on dashboard

### Features:

- Set number of days future bithdays will be shown within
- Users can hide their year of birth / age</li></ul>

__Author:__ Sebastian Stumpf
__Author website:__ [www.zeros.ones.de](http://www.zeros.ones.de)