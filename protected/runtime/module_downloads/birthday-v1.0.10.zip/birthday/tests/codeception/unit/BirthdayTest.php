<?php

namespace tests\codeception\unit\modules\birthday;

use Yii;
use tests\codeception\_support\HumHubDbTestCase;
use Codeception\Specify;

class BirthdayTest extends HumHubDbTestCase
{

    use Specify;
    
    /**
     * @inerhitdoc
     */
    protected function setUp()
    {
        parent::setUp();
    }
    
    /*
    public function testCase()
    {
        
    }
    */
}
