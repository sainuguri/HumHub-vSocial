<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Дни рождения</strong> в ближайшие {days, number} {days, plural, =1{день} =2{дня} =3{дня} =4{дня} other{дней}}',
  'Back to modules' => 'Назад к модулям',
  'Birthday Module Configuration' => 'Настройки модуля <strong>Дни рождения</strong>',
  'In {days} days' => 'Через {days, number} {days, plural, =1{день} =2{дня} =3{дня} =4{дня} other{дней}}',
  'Save' => 'Сохранить',
  'The number of days future bithdays will be shown within.' => 'Количество отображаемых в блоке дней рождения.',
  'Tomorrow' => 'завтра',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Вы можете настроить количество предстоящих дней рождения для отображения в блоке.',
  'becomes {years} years old.' => 'исполнится {years, number} {years, plural, one{год} few{года} many{лет} other{лет}}',
  'today' => 'сегодня',
);
