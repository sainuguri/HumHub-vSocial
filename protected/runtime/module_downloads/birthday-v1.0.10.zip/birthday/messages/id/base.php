<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Ulang tahun</strong> dalam selanjutnya {days} hari',
  'Back to modules' => 'Kembali ke modul',
  'Birthday Module Configuration' => 'Konfigurasi Modul Ulang Tahun',
  'In {days} days' => 'Dalam {days} Hari',
  'Save' => 'Simpan',
  'The number of days future bithdays will be shown within.' => 'Jumlah hari ulang tahun kedepan akan ditampilkan.',
  'Tomorrow' => 'Besok',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Anda dapat mengkonfigurasi jumlah hari dalam ulang tahun yang akan datang yang ditampilkan.',
  'becomes {years} years old.' => 'menjadi {years} tahun lebih tua',
  'today' => 'Hari ini',
);
