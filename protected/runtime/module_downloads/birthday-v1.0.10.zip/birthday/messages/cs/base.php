<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Narozeniny</strong> v následujících {days} dnech',
  'Back to modules' => 'Zpět na přehled modulů',
  'Birthday Module Configuration' => 'Nastavení modulu Narozeniny',
  'In {days} days' => 'Ve {days} dnech',
  'Save' => 'Uložit',
  'The number of days future bithdays will be shown within.' => 'Počet dnů v budoucnosti, ve kterých se budou zobrazovat narozeniny.',
  'Tomorrow' => 'Zítra',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Můžete nastavit počet dnů před narozeninami, kdy na ně bude upozorněno.',
  'becomes {years} years old.' => ' {years}.',
  'today' => 'dnes',
);
