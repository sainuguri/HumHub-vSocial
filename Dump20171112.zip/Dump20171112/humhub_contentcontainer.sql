-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contentcontainer`
--

DROP TABLE IF EXISTS `contentcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contentcontainer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `pk` int(11) DEFAULT NULL,
  `owner_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_target` (`class`,`pk`),
  UNIQUE KEY `unique_guid` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentcontainer`
--

LOCK TABLES `contentcontainer` WRITE;
/*!40000 ALTER TABLE `contentcontainer` DISABLE KEYS */;
INSERT INTO `contentcontainer` VALUES (1,'61c9b999-aee4-45bb-8f48-a103944fc9fd','humhub\\modules\\user\\models\\User',1,1),(2,'d426acbf-066b-425f-8b06-982c8af921e5','humhub\\modules\\space\\models\\Space',1,1),(3,'a1b6994d-f598-4245-901f-32073e361733','humhub\\modules\\user\\models\\User',2,2),(4,'3349be52-1329-43e0-9cf5-a398d1f1b66a','humhub\\modules\\user\\models\\User',3,3),(5,'63ff7cbd-4f44-4a19-b529-6e989d8e256d','humhub\\modules\\user\\models\\User',4,4),(6,'7fcfd0b9-313a-436c-a73f-9f70d65f7476','humhub\\modules\\space\\models\\Space',2,1),(7,'0491602d-e32e-4d1e-8a1a-37b9998b5376','humhub\\modules\\user\\models\\User',5,5),(8,'28ddd80d-aac9-45ad-b7ee-ee9f56793b64','humhub\\modules\\space\\models\\Space',3,5),(9,'07dee336-7409-49f3-9050-3e60577fd40a','humhub\\modules\\user\\models\\User',6,6),(10,'6a9fb03e-f42e-40b4-917f-e503eecd8bf0','humhub\\modules\\user\\models\\User',7,7),(12,'a8c8829c-34fb-4ccf-8867-2c7aae6bed88','humhub\\modules\\session\\models\\Session',8,NULL),(13,'2e5bb6cb-8db8-4aa9-9f8a-96732e4fac0c','humhub\\modules\\session\\models\\Session',9,NULL),(14,'0ca3f378-edf2-4a35-9e1f-829ab05e1d2e','humhub\\modules\\session\\models\\Session',2,NULL),(15,'7acc6c6e-4c6b-4926-995f-029eba5ab4ed','humhub\\modules\\session\\models\\Session',3,NULL),(16,'64f0f154-72ca-4bc3-b93b-53b06e8890da','humhub\\modules\\session\\models\\Session',4,NULL),(17,'eef1e1f1-0517-4ea9-b1e0-160f44f157e9','humhub\\modules\\session\\models\\Session',5,NULL),(18,'dc1d5298-7391-416a-854c-c182a71a8334','humhub\\modules\\session\\models\\Session',6,NULL),(19,'341babd7-9695-4ce5-97a4-7ed7384f7e1d','humhub\\modules\\session\\models\\Session',7,NULL),(20,'87b96b4c-f278-46fa-b9b4-bc320f75cf0e','humhub\\modules\\session\\models\\Session',10,NULL),(21,'ec77b301-e241-4330-88f0-0c23509197c6','humhub\\modules\\session\\models\\Session',11,NULL),(22,'94a8fa22-1636-4fa6-9aa8-505eb751e75d','humhub\\modules\\session\\models\\Session',12,NULL),(23,'51196da9-10a2-43d2-a101-756f025d72dc','humhub\\modules\\session\\models\\Session',13,NULL),(24,'350ba890-ec70-41e7-b677-507e1cb876fb','humhub\\modules\\session\\models\\Session',14,NULL),(25,'58b289cf-1250-47f8-813b-19c869e7dfe4','humhub\\modules\\session\\models\\Session',15,NULL),(26,'16319e17-a5c2-4794-82d6-d87b237ca772','humhub\\modules\\session\\models\\Session',16,NULL),(27,'19e43049-b9ba-41d2-8522-52b50facdba1','humhub\\modules\\session\\models\\Session',17,NULL),(28,'13c8ad8a-77f6-42ba-9708-efc331030083','humhub\\modules\\session\\models\\Session',18,NULL),(29,'daa25e73-b5ca-4740-9f7d-eb864a95ba36','humhub\\modules\\session\\models\\Session',19,NULL),(30,'76037fa5-68bc-47be-a3ad-11bf08348fec','humhub\\modules\\session\\models\\Session',20,NULL),(31,'3e1fa2c8-4b62-4a68-bcde-df2c8d715c47','humhub\\modules\\session\\models\\Session',21,NULL),(32,'206adc1e-6d84-47bc-828c-17e31542d17a','humhub\\modules\\session\\models\\Session',22,NULL),(33,'1d9fba6d-097a-4dd9-9180-56f12c0f84ac','humhub\\modules\\reward\\models\\Reward',7,NULL),(34,'bdf61edc-5b63-4eea-9e62-0f3ab039e2dd','humhub\\modules\\session\\models\\Session',23,NULL),(35,'5b97db53-ce11-473f-88e4-1361d86540de','humhub\\modules\\reward\\models\\Reward',8,NULL),(36,'8c1cde0c-6193-47c3-b3c3-9a6a7351f7ca','humhub\\modules\\session\\models\\Session',24,NULL),(37,'3f1236cb-78f2-4d31-8957-eb32de8451fe','humhub\\modules\\session\\models\\Session',25,NULL),(38,'9995e427-1bd3-4343-996a-8c7f1927d6ad','humhub\\modules\\reward\\models\\Reward',9,NULL),(39,'047fcc67-4290-4427-9099-02cb3d417f8e','humhub\\modules\\session\\models\\Session',26,NULL),(40,'2a179c39-74f8-4864-8199-826c8ae4826f','humhub\\modules\\session\\models\\Session',27,NULL),(41,'6b8f19e0-8497-4c47-9f68-b4dbe85c8b29','humhub\\modules\\reward\\models\\Reward',10,NULL),(42,'e5503b8c-59be-4039-bfa7-05d2c6f3a7ff','humhub\\modules\\session\\models\\Session',28,NULL),(43,'f7121852-a633-4f6a-8de2-4f9b9aed31a6','humhub\\modules\\reward\\models\\Reward',11,NULL),(44,'20cce5c3-3995-41f7-85fb-1db1eeedf007','humhub\\modules\\reward\\models\\Reward',12,NULL),(45,'3ca52c82-24e5-42c4-961a-652fc6cde2ca','humhub\\modules\\session\\models\\Session',1,NULL),(46,'f782117e-d001-4c87-a314-f21335c0c306','humhub\\modules\\reward\\models\\Reward',13,NULL),(47,'6e5033ce-b190-409f-b6d4-fe3c7ca60cbb','humhub\\modules\\reward\\models\\Reward',14,NULL),(48,'e8f5d1d7-e2b8-4e03-ac38-0206278e3df5','humhub\\modules\\reward\\models\\Reward',15,NULL);
/*!40000 ALTER TABLE `contentcontainer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:37
