-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_field`
--

DROP TABLE IF EXISTS `profile_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_field_category_id` int(11) NOT NULL,
  `module_id` varchar(255) DEFAULT NULL,
  `field_type_class` varchar(255) NOT NULL,
  `field_type_config` text,
  `internal_name` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `required` tinyint(4) DEFAULT NULL,
  `show_at_registration` tinyint(4) DEFAULT NULL,
  `editable` tinyint(4) NOT NULL DEFAULT '1',
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_attribute` varchar(255) DEFAULT NULL,
  `translation_category` varchar(255) DEFAULT NULL,
  `is_system` int(1) DEFAULT NULL,
  `searchable` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_profile_field_category` (`profile_field_category_id`),
  CONSTRAINT `fk_profile_field-profile_field_category_id` FOREIGN KEY (`profile_field_category_id`) REFERENCES `profile_field_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_field`
--

LOCK TABLES `profile_field` WRITE;
/*!40000 ALTER TABLE `profile_field` DISABLE KEYS */;
INSERT INTO `profile_field` VALUES (1,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":20,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','firstname','First name',NULL,100,1,1,1,1,'2017-09-07 09:31:22',NULL,'2017-09-07 09:31:22',NULL,'givenName',NULL,1,1),(2,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":30,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','lastname','Last name',NULL,200,1,1,1,1,'2017-09-07 09:31:22',NULL,'2017-09-07 09:31:23',NULL,'sn',NULL,1,1),(3,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":50,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','title','Title',NULL,300,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,'title',NULL,1,1),(4,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Select','{\"options\":\"male=>Male\\nfemale=>Female\\ncustom=>Custom\",\"fieldTypes\":[]}','gender','Gender',NULL,300,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(5,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":150,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','street','Street',NULL,400,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(6,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":10,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','zip','Zip',NULL,500,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(7,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','city','City',NULL,600,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(8,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\CountrySelect','{\"options\":null,\"fieldTypes\":[]}','country','Country',NULL,700,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(9,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','state','State',NULL,800,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(10,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Birthday','{\"defaultHideAge\":false,\"fieldTypes\":[]}','birthday','Birthday',NULL,900,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(11,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\TextArea','{\"fieldTypes\":[]}','about','About',NULL,900,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(12,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','phone_private','Phone Private',NULL,100,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(13,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','phone_work','Phone Work',NULL,200,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(14,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','mobile','Mobile',NULL,300,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(15,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','fax','Fax',NULL,400,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(16,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','im_skype','Skype Nickname',NULL,500,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(17,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','im_msn','MSN',NULL,600,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(18,2,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"email\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','im_xmpp','XMPP Jabber Address',NULL,800,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(19,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url','Url',NULL,100,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(20,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_facebook','Facebook URL',NULL,200,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(21,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_linkedin','LinkedIn URL',NULL,300,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(22,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_xing','Xing URL',NULL,400,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(23,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_youtube','Youtube URL',NULL,500,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(24,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_vimeo','Vimeo URL',NULL,600,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(25,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_flickr','Flickr URL',NULL,700,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(26,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_myspace','MySpace URL',NULL,800,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(27,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_googleplus','Google+ URL',NULL,900,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(28,3,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}','url_twitter','Twitter URL',NULL,1000,NULL,NULL,1,1,'2017-09-07 09:31:23',NULL,'2017-09-07 09:31:23',NULL,NULL,NULL,1,1),(29,1,NULL,'humhub\\modules\\user\\models\\fieldtype\\Text','{\"minLength\":\"\",\"maxLength\":\"255\",\"validator\":\"\",\"default\":\"\",\"regexp\":\"\",\"regexpErrorMessage\":\"\",\"fieldTypes\":[]}','role_name','Role','',100,0,0,0,1,'2017-10-03 10:36:29',1,'2017-10-03 10:36:29',1,'','UserModule.models_Profile',NULL,1);
/*!40000 ALTER TABLE `profile_field` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:37
