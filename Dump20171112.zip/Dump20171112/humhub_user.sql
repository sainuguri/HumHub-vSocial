-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `auth_mode` varchar(10) NOT NULL,
  `tags` text,
  `language` varchar(5) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `visibility` int(1) DEFAULT '1',
  `time_zone` varchar(100) DEFAULT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `role_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  UNIQUE KEY `unique_username` (`username`),
  UNIQUE KEY `unique_guid` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'61c9b999-aee4-45bb-8f48-a103944fc9fd',1,'sj9t5','sj9t5@mail.missouri.edu','local','Administration, Support, HumHub','','2017-09-07 09:36:04',NULL,'2017-09-07 09:36:04',NULL,'2017-11-12 15:05:17',1,NULL,1,'Administrator'),(2,'a1b6994d-f598-4245-901f-32073e361733',1,'david1986','david.roberts@example.com','local','Microsoft Office, Marketing, SEM, Digital Native','','2017-09-07 09:36:09',1,'2017-09-28 12:20:19',1,NULL,1,'America/Los_Angeles',3,'Student'),(3,'3349be52-1329-43e0-9cf5-a398d1f1b66a',1,'sara1989','sara.schuster@example.com','local','Yoga, Travel, English, German, French','','2017-09-07 09:36:10',1,'2017-09-28 12:12:28',1,NULL,1,'America/Los_Angeles',4,'Teacher'),(4,'63ff7cbd-4f44-4a19-b529-6e989d8e256d',1,'ironman','ironman@xyz.com','local',NULL,'en-US','2017-10-02 09:29:41',1,'2017-10-02 09:29:41',1,NULL,1,'America/Chicago',5,'Student'),(5,'0491602d-e32e-4d1e-8a1a-37b9998b5376',1,'calyamp','calyamp@missouri.edu','local',NULL,'en-US','2017-10-05 14:26:42',1,'2017-10-05 14:36:28',5,'2017-10-05 14:53:37',1,'America/Chicago',7,NULL),(6,'07dee336-7409-49f3-9050-3e60577fd40a',1,'abhinay','abhinay@xyz.com','local',NULL,'en-US','2017-10-05 14:29:12',5,'2017-10-05 14:33:28',1,NULL,1,'America/Chicago',9,NULL),(7,'6a9fb03e-f42e-40b4-917f-e503eecd8bf0',1,'shreya','shreya@xyz.com','local',NULL,'en-US','2017-10-05 14:30:23',5,'2017-10-05 14:33:38',1,NULL,1,'America/Chicago',10,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:36
