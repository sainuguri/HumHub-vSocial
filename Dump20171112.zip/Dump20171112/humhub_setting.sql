-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `value` text,
  `module_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unique-setting` (`name`,`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'oembedProviders','{\"vimeo.com\":\"http:\\/\\/vimeo.com\\/api\\/oembed.json?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtube.com\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtu.be\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"soundcloud.com\":\"https:\\/\\/soundcloud.com\\/oembed?url=%url%&format=json&maxwidth=450\",\"slideshare.net\":\"https:\\/\\/www.slideshare.net\\/api\\/oembed\\/2?url=%url%&format=json&maxwidth=450\"}','base'),(2,'defaultVisibility','1','space'),(3,'defaultJoinPolicy','1','space'),(4,'name','OnTimeSocial','base'),(5,'baseUrl','http://localhost/humhub','base'),(6,'paginationSize','10','base'),(7,'displayNameFormat','{profile.firstname} {profile.lastname}','base'),(8,'horImageScrollOnMobile','1','base'),(9,'auth.ldap.refreshUsers','1','user'),(10,'auth.needApproval','1','user'),(11,'auth.anonymousRegistration','1','user'),(12,'auth.internalUsersCanInvite','0','user'),(13,'mailer.transportType','php','base'),(14,'mailer.systemEmailAddress','social@example.com','base'),(15,'mailer.systemEmailName','OnTimeSocial','base'),(16,'mailSummaryInterval','2','activity'),(17,'maxFileSize','5242880','file'),(18,'maxPreviewImageWidth','200','file'),(19,'maxPreviewImageHeight','200','file'),(20,'hideImageFileInfo','0','file'),(21,'cache.class','yii\\caching\\FileCache','base'),(22,'cache.expireTime','3600','base'),(23,'installationId','aef06723cec85ef2a9cc97efdaca3aa0','admin'),(24,'theme','HumHub','base'),(25,'spaceOrder','0','space'),(26,'enable','1','tour'),(27,'defaultLanguage','en','base'),(28,'enable_html5_desktop_notifications','0','notification'),(29,'useCase','education','base'),(30,'auth.allowGuestAccess','0','user'),(31,'enable','1','friendship'),(32,'shownDays','2','birthday'),(33,'sampleData','1','installer'),(34,'secret','1adc6fd0-1864-41ad-8171-6ec57e972409','base'),(35,'colorDefault','#ededed','base'),(36,'colorPrimary','#ededed','base'),(37,'colorInfo','#ededed','base'),(38,'colorSuccess','#ededed','base'),(39,'colorWarning','#ededed','base'),(40,'colorDanger','#ededed','base'),(41,'timeZone','America/Chicago','base'),(42,'group.adminGroupId','1','user'),(43,'showProfilePostForm','0','dashboard'),(44,'defaultSort','c','stream');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:36
