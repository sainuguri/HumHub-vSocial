-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `source_class` varchar(100) DEFAULT NULL,
  `source_pk` int(11) DEFAULT NULL,
  `space_id` int(11) DEFAULT NULL,
  `emailed` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `desktop_notified` tinyint(1) DEFAULT '0',
  `originator_user_id` int(11) DEFAULT NULL,
  `module` varchar(100) DEFAULT '',
  `group_key` varchar(75) DEFAULT NULL,
  `send_web_notifications` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_user_id` (`user_id`),
  KEY `index_seen` (`seen`),
  KEY `index_desktop_notified` (`desktop_notified`),
  KEY `index_desktop_emailed` (`emailed`),
  KEY `index_groupuser` (`user_id`,`class`,`group_key`),
  CONSTRAINT `fk_notification-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,'humhub\\modules\\comment\\notifications\\NewComment',1,1,'humhub\\modules\\comment\\models\\Comment',1,1,0,'2017-09-07 09:36:10',1,2,'comment','humhub\\modules\\post\\models\\Post-2',1),(2,'humhub\\modules\\comment\\notifications\\NewComment',1,1,'humhub\\modules\\comment\\models\\Comment',2,1,0,'2017-09-07 09:36:10',1,3,'comment','humhub\\modules\\post\\models\\Post-2',1),(3,'humhub\\modules\\comment\\notifications\\NewComment',2,1,'humhub\\modules\\comment\\models\\Comment',2,1,0,'2017-09-07 09:36:10',1,3,'comment','humhub\\modules\\post\\models\\Post-2',1),(4,'humhub\\modules\\like\\notifications\\NewLike',1,1,'humhub\\modules\\like\\models\\Like',1,1,0,'2017-09-07 09:36:10',1,3,'like','humhub\\modules\\comment\\models\\Comment-1',1),(5,'humhub\\modules\\like\\notifications\\NewLike',1,1,'humhub\\modules\\like\\models\\Like',2,1,0,'2017-09-07 09:36:10',1,3,'like','humhub\\modules\\post\\models\\Post-2',1),(10,'humhub\\modules\\space\\notifications\\InviteAccepted',1,1,'humhub\\modules\\space\\models\\Space',2,2,0,'2017-10-03 14:16:58',1,2,'space',NULL,1),(13,'humhub\\modules\\space\\notifications\\InviteAccepted',5,0,'humhub\\modules\\space\\models\\Space',3,3,0,'2017-10-05 14:31:50',1,6,'space',NULL,1),(14,'humhub\\modules\\space\\notifications\\InviteAccepted',5,0,'humhub\\modules\\space\\models\\Space',3,3,0,'2017-10-05 14:32:12',1,7,'space',NULL,1),(22,'humhub\\modules\\like\\notifications\\NewLike',1,1,'humhub\\modules\\like\\models\\Like',3,1,0,'2017-10-19 15:21:52',1,2,'like','humhub\\modules\\post\\models\\Post-2',1),(23,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',95,NULL,0,'2017-10-19 15:41:14',1,1,'session',NULL,1),(26,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',97,NULL,0,'2017-10-19 16:14:14',1,1,'session',NULL,1),(27,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',98,NULL,0,'2017-10-19 16:30:15',1,1,'session',NULL,1),(28,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',98,NULL,0,'2017-10-19 16:30:15',1,1,'session',NULL,1),(29,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',98,NULL,0,'2017-10-19 16:30:15',1,1,'session',NULL,1),(30,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-10-20 11:04:19',1,1,'session',NULL,1),(31,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-10-20 11:04:20',1,1,'session',NULL,1),(32,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-10-20 11:04:20',1,1,'session',NULL,1),(33,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',2,NULL,0,'2017-10-20 11:25:52',1,2,'session',NULL,1),(34,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',3,NULL,0,'2017-10-21 16:59:57',1,1,'session',NULL,1),(35,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',4,NULL,0,'2017-10-21 18:03:18',1,1,'session',NULL,1),(36,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',6,NULL,0,'2017-10-21 19:11:44',1,1,'session',NULL,1),(37,'humhub\\modules\\session\\notifications\\Invite',3,0,'humhub\\modules\\session\\models\\Session',6,NULL,0,'2017-10-21 19:11:44',1,1,'session',NULL,1),(38,'humhub\\modules\\session\\notifications\\Invite',3,0,'humhub\\modules\\session\\models\\Session',7,NULL,0,'2017-10-21 19:29:35',1,1,'session',NULL,1),(39,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',9,NULL,0,'2017-10-24 16:08:34',0,1,'session',NULL,1),(40,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-10-25 14:11:04',1,1,'session',NULL,1),(41,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',3,NULL,0,'2017-10-30 14:58:41',0,1,'session',NULL,1),(42,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',3,NULL,0,'2017-10-30 14:58:41',0,1,'session',NULL,1),(43,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',3,NULL,0,'2017-10-30 14:58:41',1,1,'session',NULL,1),(44,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',6,NULL,0,'2017-10-30 16:39:10',0,1,'session',NULL,1),(45,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',8,NULL,0,'2017-11-01 13:20:36',0,1,'session',NULL,1),(46,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',8,NULL,0,'2017-11-01 13:20:37',1,1,'session',NULL,1),(47,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',9,NULL,0,'2017-11-01 14:41:38',0,1,'session',NULL,1),(48,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',9,NULL,0,'2017-11-01 14:41:38',1,1,'session',NULL,1),(49,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',10,NULL,0,'2017-11-01 21:38:59',0,1,'session',NULL,1),(50,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',10,NULL,0,'2017-11-01 21:38:59',0,1,'session',NULL,1),(51,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',10,NULL,0,'2017-11-01 21:38:59',1,1,'session',NULL,1),(52,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',11,NULL,0,'2017-11-08 15:22:07',0,3,'session',NULL,1),(53,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',11,NULL,0,'2017-11-08 15:22:07',1,3,'session',NULL,1),(54,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',12,NULL,0,'2017-11-09 19:02:37',0,3,'session',NULL,1),(55,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',13,NULL,0,'2017-11-09 19:05:45',0,3,'session',NULL,1),(56,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',14,NULL,0,'2017-11-09 19:08:03',0,3,'session',NULL,1),(57,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',15,NULL,0,'2017-11-09 19:09:27',0,3,'session',NULL,1),(58,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',16,NULL,0,'2017-11-09 19:15:05',0,3,'session',NULL,1),(59,'humhub\\modules\\session\\notifications\\Invite',6,0,'humhub\\modules\\session\\models\\Session',17,NULL,0,'2017-11-09 19:15:57',0,3,'session',NULL,1),(60,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',21,NULL,0,'2017-11-09 19:26:06',0,3,'session',NULL,1),(61,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',23,NULL,0,'2017-11-09 19:35:27',1,3,'session',NULL,1),(62,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',24,NULL,0,'2017-11-10 12:43:26',1,5,'session',NULL,1),(63,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',25,NULL,0,'2017-11-10 12:44:07',1,5,'session',NULL,1),(64,'humhub\\modules\\session\\notifications\\Invite',7,0,'humhub\\modules\\session\\models\\Session',27,NULL,0,'2017-11-10 12:57:28',0,5,'session',NULL,1),(65,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',28,NULL,0,'2017-11-11 16:30:06',1,3,'session',NULL,1),(66,'humhub\\modules\\session\\notifications\\Invite',4,0,'humhub\\modules\\session\\models\\Session',28,NULL,0,'2017-11-11 16:30:07',0,3,'session',NULL,1),(67,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-11-11 16:32:44',1,3,'session',NULL,1),(68,'humhub\\modules\\session\\notifications\\Invite',4,0,'humhub\\modules\\session\\models\\Session',1,NULL,0,'2017-11-11 16:32:44',0,3,'session',NULL,1),(69,'humhub\\modules\\session\\notifications\\Invite',2,0,'humhub\\modules\\session\\models\\Session',2,NULL,0,'2017-11-11 16:33:16',1,3,'session',NULL,1);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:36
