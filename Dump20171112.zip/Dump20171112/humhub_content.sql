-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: humhub
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) NOT NULL,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `visibility` tinyint(4) DEFAULT NULL,
  `pinned` tinyint(4) DEFAULT NULL,
  `archived` tinytext,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `stream_sort_date` datetime DEFAULT NULL,
  `stream_channel` char(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_object_model` (`object_model`,`object_id`),
  UNIQUE KEY `index_guid` (`guid`),
  KEY `fk-contentcontainer` (`contentcontainer_id`),
  KEY `fk-create-user` (`created_by`),
  KEY `fk-update-user` (`updated_by`),
  KEY `stream_channe` (`stream_channel`),
  CONSTRAINT `fk-contentcontainer` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk-create-user` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk-update-user` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,'a33c5454-b9a8-478e-85d0-68695111ca3c','humhub\\modules\\activity\\models\\Activity',1,1,0,'0','2017-09-07 09:36:05',1,'2017-09-07 09:36:05',1,2,'2017-09-07 09:36:05','activity'),(2,'bd9f6916-9f7a-496b-8e4a-397c3cd812a7','humhub\\modules\\post\\models\\Post',1,1,0,'0','2017-09-07 09:36:05',1,'2017-09-07 09:36:05',1,2,'2017-09-07 09:36:05','default'),(3,'8288ccca-5f36-4b0a-a380-7ca2db8c39f9','humhub\\modules\\activity\\models\\Activity',2,1,0,'0','2017-09-07 09:36:06',1,'2017-09-07 09:36:06',1,2,'2017-09-07 09:36:06','activity'),(4,'cae00bef-a135-4595-9bbc-4e2a7c154ee8','humhub\\modules\\activity\\models\\Activity',3,0,0,'0','2017-09-07 09:36:10',2,'2017-09-07 09:36:10',1,2,'2017-09-07 09:36:10','activity'),(5,'409b5687-575e-4a2a-b348-01791ded2117','humhub\\modules\\activity\\models\\Activity',4,0,0,'0','2017-09-07 09:36:10',3,'2017-09-07 09:36:10',1,2,'2017-09-07 09:36:10','activity'),(6,'2fee9831-a62f-41e8-b7cd-8126966ad8d2','humhub\\modules\\post\\models\\Post',2,0,0,'0','2017-09-07 09:36:10',1,'2017-09-07 09:36:10',1,2,'2017-09-07 09:36:10','default'),(7,'276b67d1-bdc2-43f4-aab5-c4394f2e8817','humhub\\modules\\activity\\models\\Activity',5,0,0,'0','2017-09-07 09:36:10',1,'2017-09-07 09:36:10',1,2,'2017-09-07 09:36:10','activity'),(8,'e0cae979-de2b-4768-92d2-79d4f36a22cd','humhub\\modules\\activity\\models\\Activity',6,0,0,'0','2017-09-07 09:36:10',2,'2017-09-07 09:36:10',2,2,'2017-09-07 09:36:10','activity'),(9,'d22edd13-9ff3-4e68-96c6-74e80be2d14e','humhub\\modules\\activity\\models\\Activity',7,0,0,'0','2017-09-07 09:36:10',3,'2017-09-07 09:36:10',3,2,'2017-09-07 09:36:10','activity'),(10,'25abff79-057b-4a91-99d5-2e33636fac21','humhub\\modules\\activity\\models\\Activity',8,0,0,'0','2017-09-07 09:36:10',3,'2017-09-07 09:36:10',3,2,'2017-09-07 09:36:10','activity'),(11,'89b22df8-b9ab-4580-b602-8fc9ccedcb05','humhub\\modules\\activity\\models\\Activity',9,0,0,'0','2017-09-07 09:36:10',3,'2017-09-07 09:36:10',3,2,'2017-09-07 09:36:10','activity'),(18,'30eeb0c8-a7de-49ec-aee6-95c8e04a28e4','humhub\\modules\\activity\\models\\Activity',15,0,0,'0','2017-10-02 09:29:41',4,'2017-10-02 09:29:41',1,2,'2017-10-02 09:29:41','activity'),(19,'f6f1008d-f3c0-410e-91ba-5bc1e859fe88','humhub\\modules\\activity\\models\\Activity',16,1,0,'0','2017-10-03 14:05:13',1,'2017-10-03 14:05:13',1,6,'2017-10-03 14:05:13','activity'),(20,'964bb715-6778-45d7-923b-d0520f5003d9','humhub\\modules\\activity\\models\\Activity',17,0,0,'0','2017-10-03 14:16:58',2,'2017-10-03 14:16:58',2,6,'2017-10-03 14:16:58','activity'),(21,'a2040a9f-0573-46ee-9823-455088e59d27','humhub\\modules\\activity\\models\\Activity',18,0,0,'0','2017-10-05 14:26:42',5,'2017-10-05 14:26:42',1,2,'2017-10-05 14:26:42','activity'),(22,'a2f7f442-6417-47bd-b405-44eecf84eb2f','humhub\\modules\\activity\\models\\Activity',19,1,0,'0','2017-10-05 14:28:01',5,'2017-10-05 14:28:01',5,8,'2017-10-05 14:28:01','activity'),(23,'613c9ba0-bd12-4a17-9c0c-f3186fa41180','humhub\\modules\\activity\\models\\Activity',20,0,0,'0','2017-10-05 14:29:12',6,'2017-10-05 14:29:12',5,2,'2017-10-05 14:29:12','activity'),(24,'f2c6351e-82fe-422b-b3df-4374ae62aa8d','humhub\\modules\\activity\\models\\Activity',21,0,0,'0','2017-10-05 14:30:23',7,'2017-10-05 14:30:23',5,2,'2017-10-05 14:30:23','activity'),(25,'5467346c-ec00-4ced-8301-c196519c5345','humhub\\modules\\activity\\models\\Activity',22,0,0,'0','2017-10-05 14:31:50',6,'2017-10-05 14:31:50',6,8,'2017-10-05 14:31:50','activity'),(26,'9d737d7c-d796-4660-94d8-9870b44a8d63','humhub\\modules\\activity\\models\\Activity',23,0,0,'0','2017-10-05 14:32:12',7,'2017-10-05 14:32:12',7,8,'2017-10-05 14:32:12','activity'),(27,'cad5c1ad-207a-4443-a0f9-03e7b26e8bdc','humhub\\modules\\calendar\\models\\CalendarEntry',1,0,0,'0','2017-10-16 20:04:28',1,'2017-10-16 20:04:28',1,1,'2017-10-16 20:04:28','default'),(28,'45fd0b53-a49a-4ddf-8255-17d0b51839c5','humhub\\modules\\activity\\models\\Activity',24,0,0,'0','2017-10-16 20:04:28',1,'2017-10-16 20:04:28',1,1,'2017-10-16 20:04:28','activity'),(29,'e3f7c586-5f1d-47f0-8ccd-655a70edbf8c','humhub\\modules\\activity\\models\\Activity',25,0,0,'0','2017-10-16 20:05:36',1,'2017-10-16 20:05:36',1,1,'2017-10-16 20:05:36','activity'),(39,'ef0ef8bd-926d-45a3-85ac-e748c9978bd8','humhub\\modules\\activity\\models\\Activity',35,0,0,'0','2017-10-19 15:21:52',2,'2017-10-19 15:21:52',2,2,'2017-10-19 15:21:52','activity'),(41,'dc037ee3-a900-4311-aa62-44d34748061e','humhub\\modules\\calendar\\models\\CalendarEntry',3,0,0,'0','2017-10-21 19:22:17',1,'2017-10-21 19:22:17',1,1,'2017-10-21 19:22:17','default'),(42,'f817a38a-1374-4996-8141-5f998bbd1a7d','humhub\\modules\\activity\\models\\Activity',37,0,0,'0','2017-10-21 19:22:17',1,'2017-10-21 19:22:17',1,1,'2017-10-21 19:22:17','activity'),(43,'9b96f7f0-12fa-4ef5-b84e-4c4b213948f4','humhub\\modules\\calendar\\models\\CalendarEntry',4,0,0,'0','2017-10-21 19:27:38',1,'2017-10-21 19:27:38',1,1,'2017-10-21 19:27:38','default'),(44,'0c013ee3-fa89-4f75-aab5-82b42d944e84','humhub\\modules\\activity\\models\\Activity',38,0,0,'0','2017-10-21 19:27:38',1,'2017-10-21 19:27:38',1,1,'2017-10-21 19:27:38','activity');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-12 17:52:36
